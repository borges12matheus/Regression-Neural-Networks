import pandas as pd
from keras.layers import Dense, Dropout, Activation, Input
from keras.models import Model

#Importação da base de dados
base = pd.read_csv('games.csv')
base = base.drop(['NA_Sales','EU_Sales','JP_Sales','Other_Sales', 'Developer'],axis= 1)

#-------------PRÉ PROCESSAMENTO-------------------
base = base.dropna(axis = 0)
base = base.loc[base['Global_Sales'] > 1]

#Verificando a variabilidade dos atributos
base['Name'].value_counts()
nome_jogos = base.Name
base = base.drop('Name',axis= 1)

#Definindo os previsores e o alvo/target
previsores = base.iloc[:,[0,1,2,3,5,6,7,8,9]].values
venda_global = base.iloc[:,4].values

from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
labelencoder = LabelEncoder()
previsores[:,0] = labelencoder.fit_transform(previsores[:,0])
previsores[:,2] = labelencoder.fit_transform(previsores[:,2])
previsores[:,3] = labelencoder.fit_transform(previsores[:,3])
previsores[:,8] = labelencoder.fit_transform(previsores[:,8])

#OneHotEncoder
onehotencoder = ColumnTransformer([('one_hot_encoder', OneHotEncoder(categories='auto'), [0,2,3,8])],   # Passa o número das colunas que serão transformadas
    remainder='passthrough'
)
previsores = onehotencoder.fit_transform(previsores).toarray()
#-------------------------------------------------------------
#-------------ESTRUTURA DA REDE NEURAL------------------------
camada_entrada = Input(shape=(99))
ativacao = Activation(activation= 'sigmoid')
camada_oculta1 = Dense(units= 50,activation= ativacao)(camada_entrada)
camada_dropout1 = Dropout(0.4)(camada_oculta1)
camada_oculta2 = Dense(units= 50, activation= ativacao)(camada_dropout1)
camada_saida = Dense(units= 1, activation= 'linear')(camada_oculta2)

regressor = Model(inputs = camada_entrada,
                  outputs = camada_saida)
regressor.compile(optimizer= 'adam',
                  loss='mse')
#Treinamento
regressor.fit(previsores, venda_global,
              epochs= 6000,
              batch_size= 100)
#Fazendo previsão na base de dados
previsoes = regressor.predict(previsores)